
"use strict";

const API_URL = "http://localhost:3000/api/products";
const $ = (id) => document.getElementById(id);

let products = [];
let loading = false;
let toastTimer = null;

const escapeHtml = (value) =>
  String(value ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);

const money = (value) =>
  new Intl.NumberFormat("en-PH", {
    style: "currency",
    currency: "PHP"
  }).format(Number(value) || 0);

function toast(message, type = "success") {
  const el = $("toast");
  if (!el) {
    alert(message);
    return;
  }

  el.textContent = message;
  el.className = `toast show${type === "error" ? " error" : ""}`;

  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.classList.remove("show", "error");
  }, 3500);
}

function setText(id, value) {
  const el = $(id);
  if (el) el.textContent = value;
}

function showFormError(message) {
  const el = $("formError");
  if (!el) {
    toast(message, "error");
    return;
  }
  el.textContent = message;
  el.classList.remove("hidden");
}

function clearFormError() {
  const el = $("formError");
  if (el) {
    el.textContent = "";
    el.classList.add("hidden");
  }
}

async function apiRequest(url, options = {}) {
  let response;

  try {
    response = await fetch(url, {
      ...options,
      headers: {
        ...(options.body ? { "Content-Type": "application/json" } : {}),
        ...(options.headers || {})
      }
    });
  } catch (error) {
    throw new Error(
      "Cannot connect to the backend. Ensure the server is running at http://localhost:3000."
    );
  }

  let data;
  try {
    data = await response.json();
  } catch {
    throw new Error(`Invalid server response (HTTP ${response.status}).`);
  }

  if (!response.ok || data.success === false) {
    throw new Error(data.message || `Request failed (HTTP ${response.status}).`);
  }

  return data;
}

function quantityOf(product) {
  return Number(product.quantity) || 0;
}

function minimumOf(product) {
  return Number(product.minimum ?? product.minimumStock) || 0;
}

function priceOf(product) {
  return Number(product.price) || 0;
}

function getLowStockProducts() {
  return products.filter((p) => quantityOf(p) <= minimumOf(p));
}

function getTotalUnits() {
  return products.reduce((sum, p) => sum + quantityOf(p), 0);
}

function getInventoryValue() {
  return products.reduce(
    (sum, p) => sum + priceOf(p) * quantityOf(p),
    0
  );
}

function stockStatus(product) {
  const quantity = quantityOf(product);
  const minimum = minimumOf(product);

  if (quantity === 0) {
    return '<span class="stock-status out">Out of Stock</span>';
  }

  if (quantity <= minimum) {
    return '<span class="stock-status low">Low Stock</span>';
  }

  return '<span class="stock-status in-stock">In Stock</span>';
}

function renderDashboard() {
  setText("totalProducts", products.length);
  setText("totalUnits", getTotalUnits());
  setText("lowStock", getLowStockProducts().length);
  setText("inventoryValue", money(getInventoryValue()));

  const recent = $("recentProducts");
  if (recent) {
    recent.innerHTML = products.length
      ? products.slice(0, 5).map((p) => `
          <tr>
            <td>${escapeHtml(p.name)}</td>
            <td>${escapeHtml(p.category)}</td>
            <td>${money(p.price)}</td>
            <td>${quantityOf(p)}</td>
            <td>${stockStatus(p)}</td>
          </tr>
        `).join("")
      : '<tr><td colspan="5">No products yet.</td></tr>';
  }

  $("dashboardEmpty")?.classList.toggle("hidden", products.length > 0);

  const alerts = $("stockAlerts");
  if (alerts) {
    const low = getLowStockProducts();

    alerts.innerHTML = low.length
      ? low.map((p) => `
          <div class="stock-alert">
            <strong>${escapeHtml(p.name)}</strong>
            <span>${quantityOf(p)} remaining (minimum: ${minimumOf(p)})</span>
          </div>
        `).join("")
      : "<p>No low-stock products at the moment.</p>";
  }
}

function renderProducts(searchTerm = "") {
  const body = $("productsTable");
  if (!body) return;

  const term = searchTerm.trim().toLowerCase();

  const filtered = products.filter((p) =>
    String(p.name || "").toLowerCase().includes(term) ||
    String(p.category || "").toLowerCase().includes(term)
  );

  body.innerHTML = filtered.length
    ? filtered.map((p) => `
        <tr>
          <td>${escapeHtml(p.name)}</td>
          <td>${escapeHtml(p.category)}</td>
          <td>${money(p.price)}</td>
          <td>${quantityOf(p)}</td>
          <td>${minimumOf(p)}</td>
          <td>${stockStatus(p)}</td>
          <td>
            <button type="button" class="text-button"
              data-action="edit" data-id="${escapeHtml(p.id)}">Edit</button>
            <button type="button" class="text-button"
              data-action="delete" data-id="${escapeHtml(p.id)}">Delete</button>
          </td>
        </tr>
      `).join("")
    : `<tr><td colspan="7">${
        term ? "No matching products found." : "No products yet."
      }</td></tr>`;

  $("productsEmpty")?.classList.toggle("hidden", filtered.length > 0);
}

function renderReports() {
  const el = $("reportSummary");
  if (!el) return;

  const summaries = [
    ["Total product types", products.length],
    ["Total units", getTotalUnits()],
    ["Low-stock products", getLowStockProducts().length],
    ["Inventory value", money(getInventoryValue())]
  ];

  el.innerHTML = summaries.map(([label, value]) => `
    <div class="report-item">
      <small>${escapeHtml(label)}</small>
      <strong>${escapeHtml(value)}</strong>
    </div>
  `).join("");
}

function renderInsights() {
  const el = $("insightsResult");
  if (!el) return;

  const low = getLowStockProducts();
  const outOfStock = products.filter((p) => quantityOf(p) === 0);

  const messages = products.length
    ? [
        `You have ${products.length} product type(s) in your inventory.`,
        `Your total inventory contains ${getTotalUnits()} unit(s).`,
        `Estimated inventory value: ${money(getInventoryValue())}.`,
        low.length
          ? `${low.length} product(s) are at or below minimum stock.`
          : "All products are above their minimum stock levels.",
        outOfStock.length
          ? `${outOfStock.length} product(s) are out of stock.`
          : "No products are currently out of stock."
      ]
    : ["Your inventory is empty. Add products to generate insights."];

  el.innerHTML = `<ul>${messages.map((message) =>
    `<li>${escapeHtml(message)}</li>`
  ).join("")}</ul>`;

  el.classList.remove("hidden");
}

function renderAll() {
  renderDashboard();
  renderProducts($("searchInput")?.value || "");
  renderReports();
}

function navigate(pageName) {
  const pages = ["dashboard", "products", "reports", "ai"];
  if (!pages.includes(pageName)) return;

  document.querySelectorAll("[data-page]").forEach((button) => {
    const active = button.dataset.page === pageName;
    button.classList.toggle("active", active);
    button.setAttribute("aria-current", active ? "page" : "false");
  });

  pages.forEach((name) => {
    const page = $(`${name}Page`);
    if (page) page.classList.toggle("hidden", name !== pageName);
  });

  const titles = {
    dashboard: "Dashboard",
    products: "Products",
    reports: "Reports",
    ai: "AI Insights"
  };

  setText("pageTitle", titles[pageName]);
  setText("breadcrumbPage", titles[pageName]);

  if (pageName === "products") {
    renderProducts($("searchInput")?.value || "");
  }

  if (pageName === "reports") renderReports();
  if (pageName === "ai") renderInsights();
}

window.navigate = navigate;

function openProductDialog(product = null) {
  const dialog = $("productDialog");
  const form = $("productForm");

  if (!dialog || !form) {
    toast("Product form could not be found.", "error");
    return;
  }

  form.reset();
  clearFormError();

  setText("dialogTitle", product ? "Edit Product" : "Add Product");

  $("productId").value = product?.id ?? "";
  $("productName").value = product?.name ?? "";
  $("productCategory").value = product?.category ?? "";
  $("productPrice").value = product?.price ?? "";
  $("productQuantity").value = product?.quantity ?? "";
  $("productMinimum").value = product
    ? minimumOf(product)
    : 5;

  if (!dialog.open) dialog.showModal();

  $("productName").focus();
}

function closeProductDialog() {
  const dialog = $("productDialog");
  if (dialog?.open) dialog.close();
}

function readProductForm() {
  const name = $("productName").value.trim();
  const category = $("productCategory").value.trim();
  const priceText = $("productPrice").value;
  const quantityText = $("productQuantity").value;
  const minimumText = $("productMinimum").value;

  if (!name || !category) {
    throw new Error("Enter both the product name and category.");
  }

  if (priceText === "" || quantityText === "" || minimumText === "") {
    throw new Error("Complete all price and stock fields.");
  }

  const price = Number(priceText);
  const quantity = Number(quantityText);
  const minimum = Number(minimumText);

  if (!Number.isFinite(price) || price < 0) {
    throw new Error("Price must be zero or greater.");
  }

  if (!Number.isInteger(quantity) || quantity < 0) {
    throw new Error("Quantity must be a whole number of zero or greater.");
  }

  if (!Number.isInteger(minimum) || minimum < 0) {
    throw new Error("Minimum stock must be a whole number of zero or greater.");
  }

  return { name, category, price, quantity, minimum };
}

async function loadProducts() {
  if (loading) return;
  loading = true;

  try {
    const result = await apiRequest(API_URL);

    // Supports the API response format used by the backend.
    const list = Array.isArray(result.products)
      ? result.products
      : Array.isArray(result.data)
        ? result.data
        : [];

    products = list.map((p) => ({
      ...p,
      id: String(p.id ?? p.productId ?? ""),
      minimum: Number(p.minimum ?? p.minimumStock) || 0
    }));

    renderAll();
    console.log("MiniInventory: loaded", products.length, "products.");
  } catch (error) {
    console.error("Load products failed:", error);
    toast(error.message, "error");
  } finally {
    loading = false;
  }
}

async function saveProduct(event) {
  event.preventDefault();

  const form = $("productForm");
  if (!form || form.dataset.submitting === "true") return;

  clearFormError();

  let submitButton = null;

  try {
    const data = readProductForm();
    const id = $("productId").value.trim();

    form.dataset.submitting = "true";
    submitButton = form.querySelector('[type="submit"]');

    if (submitButton) submitButton.disabled = true;

    if (id) {
      await apiRequest(`${API_URL}/${encodeURIComponent(id)}`, {
        method: "PUT",
        body: JSON.stringify(data)
      });
      toast("Product updated successfully.");
    } else {
      await apiRequest(API_URL, {
        method: "POST",
        body: JSON.stringify(data)
      });
      toast("Product added successfully.");
    }

    closeProductDialog();
    await loadProducts();
  } catch (error) {
    console.error("Save product failed:", error);
    showFormError(error.message || "Unable to save product.");
  } finally {
    delete form.dataset.submitting;
    if (submitButton) submitButton.disabled = false;
  }
}

async function deleteProduct(id) {
  const product = products.find((p) => String(p.id) === String(id));

  if (!product) {
    toast("Product not found. Refreshing inventory.", "error");
    await loadProducts();
    return;
  }

  if (!window.confirm(`Delete "${product.name}"? This cannot be undone.`)) {
    return;
  }

  try {
    await apiRequest(`${API_URL}/${encodeURIComponent(id)}`, {
      method: "DELETE"
    });

    toast("Product deleted successfully.");
    await loadProducts();
  } catch (error) {
    console.error("Delete product failed:", error);
    toast(error.message, "error");
  }
}

function exportProducts() {
  if (!products.length) {
    toast("There are no products to export.", "error");
    return;
  }

  const rows = [
    ["Product Name", "Category", "Price", "Quantity", "Minimum Stock", "Inventory Value"],
    ...products.map((p) => [
      p.name,
      p.category,
      priceOf(p),
      quantityOf(p),
      minimumOf(p),
      priceOf(p) * quantityOf(p)
    ])
  ];

  const csv = rows.map((row) => row.map((value) =>
    `"${String(value ?? "").replace(/"/g, '""')}"`
  ).join(",")).join("\r\n");

  const blob = new Blob(["\uFEFF", csv], {
    type: "text/csv;charset=utf-8;"
  });

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = "miniinventory-products.csv";
  document.body.appendChild(link);
  link.click();
  link.remove();

  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast("CSV report exported.");
}

function initializeApp() {
  // Prevent duplicate event listeners.
  if (document.body.dataset.appInitialized === "true") return;
  document.body.dataset.appInitialized = "true";

  document.querySelectorAll("[data-page]").forEach((button) => {
    button.addEventListener("click", () => navigate(button.dataset.page));
  });

  document.querySelectorAll("[data-go]").forEach((button) => {
    button.addEventListener("click", () => navigate(button.dataset.go));
  });

  $("homeLink")?.addEventListener("click", (event) => {
    event.preventDefault();
    navigate("dashboard");
  });

  $("addProductTop")?.addEventListener("click", () => openProductDialog());
  $("addProductButton")?.addEventListener("click", () => openProductDialog());
  $("closeDialog")?.addEventListener("click", closeProductDialog);
  $("productForm")?.addEventListener("submit", saveProduct);

  $("productDialog")?.addEventListener("click", (event) => {
    if (event.target === $("productDialog")) closeProductDialog();
  });

  $("searchInput")?.addEventListener("input", (event) => {
    renderProducts(event.target.value);
  });

  $("productsTable")?.addEventListener("click", async (event) => {
    const button = event.target.closest("button[data-action]");
    if (!button) return;

    const id = button.dataset.id;
    if (!id) return;

    if (button.dataset.action === "edit") {
      const product = products.find((p) => String(p.id) === String(id));

      if (product) openProductDialog(product);
      else toast("Product not found.", "error");
    }

    if (button.dataset.action === "delete") {
      await deleteProduct(id);
    }
  });

  $("exportButton")?.addEventListener("click", exportProducts);
  $("insightsButton")?.addEventListener("click", renderInsights);

  navigate("dashboard");
  loadProducts();

  console.log("MiniInventory initialized successfully.");
}

window.addEventListener("error", (event) => {
  console.error(
    "MiniInventory JavaScript error:",
    event.message,
    event.filename,
    event.lineno
  );
});

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializeApp, { once: true });
} else {
  initializeApp();
}
